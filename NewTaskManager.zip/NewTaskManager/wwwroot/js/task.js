class Task{

    constructor(id, important, title, dateTime, description, status, location, alertText){
    //this.id=id;  
    this.important=important;
    this.title=title;
    this.dueDate=dateTime;
    this.description=description;
    this.status=status;
    this.location=location;
    this.alertText=alertText;
    
    this.user="M.A."
    }
}